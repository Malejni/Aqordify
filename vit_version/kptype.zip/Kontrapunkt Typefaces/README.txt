	THANK YOU
	
Thank you for downloading our typefaces. Please feel free to use the fonts as you wish - just don't resell them.

We're really interested in seeing the results, so please do drop us a line with an image or two of your work with the font at mail@kontrapunkt.com or share it in our Flickr Group Pool: http://www.flickr.com/groups/kptype/

	COPYRIGHT AND LICENSE

CC Kontrapunkt A/S
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)

www.kontrapunkt.com 
www.kontrapunkt.com/type

For more information concerning the license, please read LICENSE.TXT

	FOLLOW US

http://twitter.com/kontrapunkt_com
http://www.facebook.com/pages/Kontrapunkt/273977069282809

	HOW TO INSTALL FONTS

	Installing OpenType and TrueType fonts in Windows, and PostScript Type 1 fonts in Windows 2000+, XP, and Vista

In versions prior to Windows XP, Choose Start > Settings > Control Panel. In Windows XP and later, choose Start > Control Panel.
Double-click the Fonts folder. If you don't see a Fonts folder in Windows XP or Vista, please switch the control panel to Classic Mode
Choose File > Install New Font.
Locate the fonts you want to install. In the Drives list, select the drive and the folder containing the fonts you want to install. In the Folders list, select a folder that contains the fonts you want to install. (Make sure you have unzipped them first.) The fonts in the folder appear under List of Fonts.
Select the fonts to install. To select more than one font, hold down the CTRL key and select each font. To select a list of fonts to install, select the first font in the list, press the SHIFT key, then select the last font in the list. All of the fonts in between will be selected.
To copy the fonts to the Fonts folder, make sure the Copy fonts to the Fonts folder check box is selected. If you are installing fonts from a floppy disk or a CD-ROM, you should make sure this check box is selected. Otherwise, you will have to keep this disk or CD-ROM available to use the fonts in your applications.
Click OK to install the fonts.
Installing PostScript Type 1 Fonts in Windows Me/98/95 or Windows NT

	Installing PostScript, OpenType, or TrueType Fonts in Mac OS X

Before installing fonts, you should close any open applications. For some applications, new fonts do not appear in the font menu if you install them while the application is open.
In the Finder, open the folder or disk that contains the fonts you want to install.
Select the font suitcases for the fonts you want to install. For PostScript Type 1 fonts, select the printer outline files as well.
Drag and drop the fonts into the Fonts folder in the Library folder. If you want fonts to be available to applications running in Classic mode, you must install fonts in Macintosh TrueType or Macintosh PostScript format into the Fonts folder inside the Classic System folder.
For a thorough in-depth description of all aspects of fonts on Mac OS X, we suggest the eBook Take Control of Fonts in Mac OS X published by TidBITS.

	Installing PostScript or TrueType Fonts in Mac OS 9.x or 8.x

Macintosh System 9.x allows you to open 512 suitcases at once. Macintosh System 8.x and earlier only allow you to open 128 font suitcases at one time. If you exceed these limits, not all the fonts you install will work.

Before installing fonts, you should close any open applications. For some applications, new fonts do not appear in the font menu if you install them while the application is open.
In the Finder, open the folder or disk that contains the fonts you want to install.
Select the font suitcases for the fonts you want to install. For PostScript Type 1 fonts, select the printer outline files as well.
Drag and drop the fonts onto the closed System Folder icon.
Click OK to install the fonts.